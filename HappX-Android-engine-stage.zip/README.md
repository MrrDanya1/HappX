# HappX Android

Android project with a dark-green UI, local profile list, VLESS/VMess/Trojan share-link parsing, sing-box JSON generation, and the native `libbox` runtime dependency.

## Build APK on your phone with GitHub Actions

1. Create a GitHub repository and upload the **contents** of this project to its root.
2. Open the repository's **Actions** tab and run **HappX Android APK** (`Run workflow`).
3. Open the finished run, find **Artifacts**, and download `HappX-debug-apk`.
4. Unzip the artifact and install the debug APK on Android.

## Current status — read before installing

This is an in-progress development build, **not yet a working VPN/proxy client**. The libbox native runtime is included and initialized, and supported share links are parsed into sing-box configurations. However, the Android `PlatformInterface`/`CommandServer` bridge and actual VPN tunnel lifecycle are not yet implemented. The Connect button intentionally does not claim success, and speed/ping values are shown as unavailable rather than fake statistics.

The current app does not download remote subscriptions yet; an HTTP(S) subscription URL can be saved but cannot be used to connect.

## Licensing

The `libbox` dependency is GPL-3.0. Review `THIRD_PARTY_NOTICES.md` and the upstream license before redistributing this app or its APK.
