# Third-party notices

## sing-box / libbox

HappX includes the Android `libbox` library for sing-box, version 1.14.3, distributed under the GNU General Public License version 3.0 (GPL-3.0). Upstream project: https://github.com/singbox-android/libbox

Review the upstream license and the obligations that apply before distributing builds. This repository does not claim the libbox engine is proprietary.
