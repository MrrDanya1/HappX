plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.happx"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.happx"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}


dependencies {
    // sing-box native Android engine (GPL-3.0). Runtime bridge is documented separately.
    implementation("com.github.singbox-android:libbox:1.14.3")
}
