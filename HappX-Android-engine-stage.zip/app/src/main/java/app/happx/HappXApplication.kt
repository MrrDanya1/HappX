package app.happx

import android.app.Application
import android.os.Build
import android.util.Log
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.SetupOptions
import java.io.File
import java.util.Locale

/** Initializes the bundled sing-box native runtime. This does not start a VPN tunnel by itself. */
class HappXApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            val base = File(filesDir, "happx").apply { mkdirs() }
            val working = File(getExternalFilesDir(null) ?: filesDir, "happx-work").apply { mkdirs() }
            val temp = File(cacheDir, "happx").apply { mkdirs() }
            Libbox.setLocale(Locale.getDefault().toLanguageTag())
            val options = SetupOptions().apply {
                basePath = base.absolutePath
                workingPath = working.absolutePath
                tempPath = temp.absolutePath
                debug = BuildConfig.DEBUG
                appVersion = BuildConfig.VERSION_CODE.toString()
                appMarketingVersion = BuildConfig.VERSION_NAME
                platformMetadata = "{\"os\":\"Android ${Build.VERSION.RELEASE}\",\"sdk\":${Build.VERSION.SDK_INT}}"
            }
            Libbox.setup(options)
            Log.i("HappX", "sing-box native runtime initialized")
        }.onFailure {
            // Keep the app usable for profile management; the UI will not claim VPN is connected.
            Log.e("HappX", "Could not initialize sing-box runtime", it)
        }
    }
}
