package app.happx

import android.net.VpnService

/**
 * VPN service declaration for the project scaffold.
 * The actual tunnel is intentionally not implemented yet.
 * Do not present this service as a working proxy/VPN engine.
 */
class HappXVpnService : VpnService()
