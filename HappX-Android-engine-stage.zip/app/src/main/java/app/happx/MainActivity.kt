package app.happx

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 20, 15)
    private val panel = Color.rgb(19, 38, 28)
    private val green = Color.rgb(105, 222, 151)
    private val text = Color.rgb(240, 250, 243)
    private val muted = Color.rgb(157, 185, 167)

    private val servers = mutableListOf<String>()
    private val serverConfigs = mutableMapOf<String, String>()
    private val prefs by lazy { getSharedPreferences("happx_profiles", MODE_PRIVATE) }
    private var selectedIndex = -1
    private lateinit var serverList: LinearLayout
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private lateinit var selectedServer: TextView
    private var connected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        servers.addAll(prefs.getStringSet("servers", emptySet()).orEmpty().sorted())
        for (entry in servers) {
            val raw = entry.substringAfter("|", "")
            if (raw.startsWith("vless://") || raw.startsWith("vmess://") || raw.startsWith("trojan://")) {
                runCatching { serverConfigs[entry] = SingBoxConfigBuilder.parseShareLink(raw).configJson }
            }
        }
        selectedIndex = servers.indexOf(prefs.getString("selected_entry", null)).takeIf { it >= 0 } ?: -1
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("HappX", 30, text, true))
        content.addView(label("PRIVATE CONNECTION  •  ANDROID", 11, muted, true).apply {
            setPadding(0, dp(4), 0, dp(24))
        })

        val connectionCard = card()
        connectionCard.gravity = Gravity.CENTER
        connectionCard.setPadding(dp(16), dp(22), dp(16), dp(22))
        status = label("Отключено", 21, text, true)
        connectionCard.addView(status)
        connectionCard.addView(label("Выбери сервер для подключения", 13, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(18))
        })
        connectButton = Button(this).apply {
            text = "⏻   ПОДКЛЮЧИТЬ"
            setTextColor(Color.rgb(6, 25, 15))
            textSize = 15f
            isAllCaps = false
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { requestConnection() }
        }
        connectionCard.addView(connectButton, LinearLayout.LayoutParams(-1, dp(54)))
        content.addView(connectionCard, marginParams(bottom = 16))

        content.addView(label("СТАТИСТИКА", 12, muted, true).apply {
            setPadding(0, dp(2), 0, dp(8))
        })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("— KB/s", "Приём"), LinearLayout.LayoutParams(0, dp(82), 1f))
        stats.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        stats.addView(statCard("— KB/s", "Отправка"), LinearLayout.LayoutParams(0, dp(82), 1f))
        stats.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        stats.addView(statCard("— ms", "Пинг"), LinearLayout.LayoutParams(0, dp(82), 1f))
        content.addView(stats, marginParams(bottom = 22))

        content.addView(label("СЕРВЕРЫ", 12, muted, true).apply {
            setPadding(0, 0, 0, dp(8))
        })
        serverList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(serverList)
        selectedServer = label("Сервер не выбран", 13, muted, false)
        content.addView(selectedServer.apply { setPadding(0, dp(6), 0, dp(12)) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addButton = Button(this).apply {
            text = "＋ Добавить подписку"
            isAllCaps = false
            setTextColor(text)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener { showImportDialog() }
        }
        val qrButton = Button(this).apply {
            text = "▦ QR"
            isAllCaps = false
            setTextColor(text)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Сканирование QR добавим на следующем этапе.", Toast.LENGTH_LONG).show()
            }
        }
        actions.addView(addButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        actions.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(qrButton, LinearLayout.LayoutParams(dp(95), dp(52)))
        root.addView(actions)
        setContentView(root)
        refreshServers()
    }

    private fun requestConnection() {
        if (connected) {
            connected = false
            status.text = "Отключено"
            connectButton.text = "⏻   ПОДКЛЮЧИТЬ"
            Toast.makeText(this, "Подключение не запущено: мост libbox ↔ Android VPN ещё не завершён.", Toast.LENGTH_LONG).show()
            return
        }
        if (servers.isEmpty()) {
            Toast.makeText(this, "Сначала добавь ссылку подписки или сервер.", Toast.LENGTH_LONG).show()
            return
        }
        if (selectedIndex !in servers.indices) {
            Toast.makeText(this, "Сначала выбери сервер из списка.", Toast.LENGTH_LONG).show()
            return
        }
        val selected = servers[selectedIndex]
        if (!serverConfigs.containsKey(selected)) {
            Toast.makeText(this, "Это ссылка подписки. Импорт подписок ещё нужно подключить к загрузчику профилей.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Конфигурация sing-box подготовлена. Запуск VPN ещё не активен: не хочу показывать ложное подключение.", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 700 && resultCode == RESULT_OK) {
            Toast.makeText(this, "Разрешение Android получено, но VPN-движок пока не запущен.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showImportDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val nameInput = EditText(this).apply {
            hint = "Название сервера или подписки"
            setSingleLine(true)
        }
        val urlInput = EditText(this).apply {
            hint = "Ссылка подписки / конфигурации"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        box.addView(nameInput)
        box.addView(urlInput)
        AlertDialogBuilder(this)
            .setTitle("Добавить сервер")
            .setView(box)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Добавить") { _, _ ->
                val url = urlInput.text.toString().trim()
                if (url.isBlank()) {
                    Toast.makeText(this, "Введи ссылку конфигурации.", Toast.LENGTH_SHORT).show()
                } else {
                    val supported = url.startsWith("vless://", true) || url.startsWith("vmess://", true) || url.startsWith("trojan://", true)
                    val subscription = url.startsWith("https://", true) || url.startsWith("http://", true)
                    if (!supported && !subscription) {
                        Toast.makeText(this, "Вставь VLESS/VMess/Trojan или HTTPS-ссылку подписки.", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                    try {
                        val parsed = if (supported) SingBoxConfigBuilder.parseShareLink(url) else null
                        val name = nameInput.text.toString().trim().ifBlank { parsed?.name ?: "Подписка ${servers.size + 1}" }
                        val entry = "$name|$url"
                        if (entry !in servers) servers.add(entry)
                        if (parsed != null) serverConfigs[entry] = parsed.configJson
                        selectedIndex = servers.indexOf(entry)
                        persistServers()
                        refreshServers()
                        Toast.makeText(this, if (parsed != null) "Профиль ${parsed.type} сохранён; конфигурация sing-box создана." else "Ссылка подписки сохранена. Загрузчик подписок ещё не подключён.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, e.message ?: "Не удалось разобрать ссылку.", Toast.LENGTH_LONG).show()
                    }
                }
            }.show()
    }

    private fun refreshServers() {
        if (!::serverList.isInitialized) return
        serverList.removeAllViews()
        if (servers.isEmpty()) {
            val empty = card()
            empty.addView(label("Пока нет серверов", 15, text, true))
            empty.addView(label("Добавь ссылку подписки или конфигурации.", 12, muted, false).apply {
                setPadding(0, dp(5), 0, 0)
            })
            serverList.addView(empty, marginParams(bottom = 8))
            selectedServer.text = "Сервер не выбран"
            return
        }
        selectedServer.text = if (selectedIndex in servers.indices) "Выбран: ${servers[selectedIndex].substringBefore("|")}" else "Сервер не выбран"
        servers.forEachIndexed { index, entry ->
            val name = entry.substringBefore("|")
            val row = card().apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setOnClickListener {
                    selectedIndex = index
                    prefs.edit().putString("selected_entry", entry).apply()
                    selectedServer.text = "Выбран: $name"
                    Toast.makeText(this@MainActivity, "Выбран сервер: $name", Toast.LENGTH_SHORT).show()
                    refreshServers()
                }
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(name, 15, text, true))
            info.addView(label(if (entry in serverConfigs) "${if (index == selectedIndex) "✓ Выбран · " else ""}Профиль ${runCatching { SingBoxConfigBuilder.parseShareLink(entry.substringAfter("|" )).type }.getOrDefault("sing-box")}" else "${if (index == selectedIndex) "✓ Выбран · " else ""}Ссылка подписки", 11, muted, false).apply {
                setPadding(0, dp(4), 0, 0)
            })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val remove = Button(this).apply {
                text = "×"
                isAllCaps = false
                setTextColor(muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    val removed = servers.removeAt(index)
                    serverConfigs.remove(removed)
                    if (selectedIndex == index) selectedIndex = -1 else if (selectedIndex > index) selectedIndex--
                    persistServers()
                    refreshServers()
                }
            }
            row.addView(remove)
            serverList.addView(row, marginParams(bottom = 8))
        }
    }

    private fun persistServers() {
        prefs.edit().putStringSet("servers", servers.toSet()).putString("selected_entry", servers.getOrNull(selectedIndex)).apply()
    }

    private fun statCard(value: String, caption: String): LinearLayout {
        val c = card()
        c.setPadding(dp(8), dp(12), dp(8), dp(10))
        c.gravity = Gravity.CENTER
        c.addView(label(value, 13, text, true))
        c.addView(label(caption, 11, muted, false).apply { setPadding(0, dp(5), 0, 0) })
        return c
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(18).toFloat()
        }
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

/** Small helper to keep the prototype dependency-free. */
private class AlertDialogBuilder(activity: Activity) : android.app.AlertDialog.Builder(activity)
