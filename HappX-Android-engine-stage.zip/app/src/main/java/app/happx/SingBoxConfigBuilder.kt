package app.happx

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** Parses common share links and builds a sing-box JSON configuration for review/testing. */
object SingBoxConfigBuilder {
    data class ParsedServer(val name: String, val type: String, val configJson: String)

    fun parseShareLink(raw: String): ParsedServer {
        val link = raw.trim()
        require(link.isNotBlank()) { "Ссылка пустая" }
        return when {
            link.startsWith("vless://", true) -> parseVless(link)
            link.startsWith("trojan://", true) -> parseTrojan(link)
            link.startsWith("vmess://", true) -> parseVmess(link)
            else -> throw IllegalArgumentException("Пока поддерживаются VLESS, VMess и Trojan-ссылки")
        }
    }

    private fun parseVless(link: String): ParsedServer {
        val uri = Uri.parse(link)
        val uuid = uri.userInfo?.substringBefore(':')?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В VLESS-ссылке не найден UUID")
        val host = uri.host?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В ссылке не найден адрес сервера")
        val port = uri.port.takeIf { it in 1..65535 }
            ?: throw IllegalArgumentException("Неверный порт сервера")
        val query = uri.queryParameterNames.associateWith { uri.getQueryParameter(it).orEmpty() }
        val security = query["security"].orEmpty()
        val tls = security == "tls" || security == "reality"
        val outbound = JSONObject()
            .put("type", "vless")
            .put("tag", "proxy")
            .put("server", host)
            .put("server_port", port)
            .put("uuid", uuid)
        val network = query["type"].orEmpty()
        if (network.isNotBlank() && network != "tcp") {
            outbound.put("transport", JSONObject().put("type", network).apply {
                query["path"]?.takeIf { it.isNotBlank() }?.let { put("path", it) }
                query["host"]?.takeIf { it.isNotBlank() }?.let { put("headers", JSONObject().put("Host", it)) }
            })
        }
        if (tls) {
            val tlsObject = JSONObject().put("enabled", true)
            query["sni"]?.takeIf { it.isNotBlank() }?.let { tlsObject.put("server_name", it) }
            query["fp"]?.takeIf { it.isNotBlank() }?.let { tlsObject.put("utls", JSONObject().put("enabled", true).put("fingerprint", it)) }
            if (security == "reality") {
                val publicKey = query["pbk"].orEmpty()
                require(publicKey.isNotBlank()) { "В REALITY-ссылке не найден параметр pbk" }
                val reality = JSONObject().put("enabled", true).put("public_key", publicKey)
                query["sid"]?.takeIf { it.isNotBlank() }?.let { reality.put("short_id", it) }
                tlsObject.put("reality", reality)
            }
            outbound.put("tls", tlsObject)
        }
        return ParsedServer(label(uri, host), "VLESS", baseConfig(outbound))
    }

    private fun parseTrojan(link: String): ParsedServer {
        val uri = Uri.parse(link)
        val password = uri.userInfo?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В Trojan-ссылке не найден пароль")
        val host = uri.host?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В ссылке не найден адрес сервера")
        val port = uri.port.takeIf { it in 1..65535 }
            ?: throw IllegalArgumentException("Неверный порт сервера")
        val outbound = JSONObject().put("type", "trojan").put("tag", "proxy")
            .put("server", host).put("server_port", port).put("password", password)
            .put("tls", JSONObject().put("enabled", true).put("server_name", uri.getQueryParameter("sni") ?: host))
        return ParsedServer(label(uri, host), "Trojan", baseConfig(outbound))
    }

    private fun parseVmess(link: String): ParsedServer {
        val payload = link.removePrefix("vmess://")
        val decoded = try {
            String(Base64.decode(payload, Base64.DEFAULT), StandardCharsets.UTF_8)
        } catch (_: Exception) {
            throw IllegalArgumentException("Не удалось прочитать VMess-ссылку")
        }
        val data = try { JSONObject(decoded) } catch (_: Exception) {
            throw IllegalArgumentException("Некорректные данные VMess")
        }
        val host = data.optString("add").takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В VMess-ссылке не найден адрес")
        val port = data.optString("port").toIntOrNull()?.takeIf { it in 1..65535 }
            ?: throw IllegalArgumentException("Неверный порт VMess")
        val uuid = data.optString("id").takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("В VMess-ссылке не найден UUID")
        val outbound = JSONObject().put("type", "vmess").put("tag", "proxy")
            .put("server", host).put("server_port", port).put("uuid", uuid)
            .put("security", data.optString("scy", "auto"))
        val network = data.optString("net", "tcp")
        if (network == "ws") {
            outbound.put("transport", JSONObject().put("type", "ws").put("path", data.optString("path", "/"))
                .put("headers", JSONObject().put("Host", data.optString("host", host))))
        }
        if (data.optString("tls") == "tls") {
            outbound.put("tls", JSONObject().put("enabled", true).put("server_name", data.optString("sni", data.optString("host", host))))
        }
        return ParsedServer(data.optString("ps").ifBlank { host }, "VMess", baseConfig(outbound))
    }

    private fun label(uri: Uri, host: String): String = uri.fragment
        ?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrNull() }
        ?.takeIf { it.isNotBlank() } ?: host

    private fun baseConfig(outbound: JSONObject): String {
        val direct = JSONObject().put("type", "direct").put("tag", "direct")
        val dns = JSONObject().put("servers", JSONArray().put(JSONObject().put("tag", "dns-remote").put("address", "https://1.1.1.1/dns-query").put("detour", "proxy")))
        val route = JSONObject().put("auto_detect_interface", true)
            .put("final", "proxy")
        return JSONObject().put("log", JSONObject().put("level", "info"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(JSONObject().put("type", "tun").put("tag", "tun-in")
                .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                .put("auto_route", true).put("strict_route", true)))
            .put("outbounds", JSONArray().put(outbound).put(direct))
            .put("route", route).toString(2)
    }
}
