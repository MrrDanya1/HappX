# HappX + sing-box integration status

## Included in this stage

- The Android build includes `com.github.singbox-android:libbox:1.14.3` (sing-box native Android runtime).
- `HappXApplication` initializes libbox directories and `SetupOptions` at app startup.
- The app accepts VLESS, VMess and Trojan share links and generates a sing-box JSON configuration for supported links.
- Server entries are saved locally in Android SharedPreferences.
- The UI deliberately does **not** report a successful connection when no tunnel is running.

## Still required for a real connection

Bundling and initializing libbox is not the same as starting a VPN. The next runtime task is to implement the `PlatformInterface` bridge, create a `CommandServer`/`CommandServerHandler`, establish the Android `VpnService` TUN descriptor, start the generated configuration, and expose real lifecycle/statistics callbacks. The current `HappXVpnService` remains a stub and the Connect button does not start traffic. Do not distribute this build as a working VPN client yet.

## Licensing

The libbox dependency is GPL-3.0. If distributing an app that includes it, review the GPL-3.0 obligations for the combined work and provide the required corresponding source and license notices. This project is not represented as a proprietary closed-source app.

## References

- https://github.com/singbox-android/libbox
- https://sing-box.sagernet.org/clients/android/features/
